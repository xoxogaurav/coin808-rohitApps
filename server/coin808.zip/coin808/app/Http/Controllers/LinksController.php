<?php

namespace App\Http\Controllers;

use App\Models\bannerLinks;
use App\Models\other_links;
use Illuminate\Http\Request;

class LinksController extends Controller
{
    

    public Static function fetchLinks()
    {
    
         return response()->json([
            'status' => true,
            'message' => 'all links',
            'otherlinks' => other_links::all(),
            'bannerLinks' => bannerLinks::all(),

        ], 200);
    }

}
